
import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
from prophet import Prophet
import yfinance as yf

st.title("Reliance Stock Price Forecast")
st.write("This app forecasts Reliance stock prices using Facebook Prophet.")

# Load data
data = yf.download("RELIANCE.NS", start="2015-01-01", end="2024-12-31")
data.reset_index(inplace=True)
df = data[["Date", "Close"]]
df.rename(columns={"Date": "ds", "Close": "y"}, inplace=True)

# Train Prophet
model = Prophet()
model.fit(df)

# Forecast
future = model.make_future_dataframe(periods=60)
forecast = model.predict(future)

# Plot
fig1 = model.plot(forecast)
st.pyplot(fig1)

fig2 = model.plot_components(forecast)
st.pyplot(fig2)
